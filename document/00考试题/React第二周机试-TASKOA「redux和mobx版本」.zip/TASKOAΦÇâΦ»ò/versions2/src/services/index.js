import http from './http';

// 获取指定状态的任务信息
const getTaskList = (state = 0) => {
    return http.get('/api/getTaskList', {
        params: {
            state
        }
    });
};

// 新增任务
const addTask = (task, time) => {
    return http.post('/api/addTask', {
        task,
        time
    });
};

// 删除任务
const removeTask = (id) => {
    return http.get('/api/removeTask', {
        params: {
            id
        }
    });
};

// 完成任务
const completeTask = (id) => {
    return http.get('/api/completeTask', {
        params: {
            id
        }
    });
};

/* 暴露API */
const api = {
    getTaskList,
    addTask,
    removeTask,
    completeTask
};
export default api;