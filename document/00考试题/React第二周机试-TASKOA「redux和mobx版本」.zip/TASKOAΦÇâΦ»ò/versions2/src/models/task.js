export default {
    namespace: 'task',
    state: {},
    reducers: {},
    effects: {},
    subscriptions: {}
};