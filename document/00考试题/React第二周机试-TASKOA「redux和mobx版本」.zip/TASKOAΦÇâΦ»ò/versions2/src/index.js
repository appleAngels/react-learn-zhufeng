import dva from 'dva';
import createLoading from 'dva-loading';
import taskModel from './models/task';

const app = dva();
app.use(createLoading());
app.model(taskModel);
app.router(require('./router').default);
app.start('#root');