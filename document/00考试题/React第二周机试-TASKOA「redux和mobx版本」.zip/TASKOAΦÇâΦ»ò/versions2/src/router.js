import React from 'react';
import { Router, Route, Switch, Redirect } from 'dva/router';
import Task from './routes/Task';

/* ANTD */
import { ConfigProvider } from 'antd';
import zhCN from 'antd/es/locale/zh_CN';
import './index.less';

export default function RouterConfig({ history }) {
  return <ConfigProvider locale={zhCN}>
    <Router history={history}>
      <Switch>
        <Route path="/" exact component={Task} />
        <Redirect path='*' to="/" />
      </Switch>
    </Router>
  </ConfigProvider>;
};