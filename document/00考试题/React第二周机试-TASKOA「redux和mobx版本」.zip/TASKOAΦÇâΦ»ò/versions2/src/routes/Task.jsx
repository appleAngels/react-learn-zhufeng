import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { Button, DatePicker, Form, Input, Modal, Popconfirm, Table, Tag, message } from 'antd';

/* 组件样式 */
const StyledVoteBox = styled.div`
    box-sizing: border-box;
    margin: 0 auto;
    width: 800px;
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-bottom: 10px;
        border-bottom: 1px solid #DDD;
        .title {
            font-size: 20px;
            line-height: 50px;
        }
    }
    .tag-box {
        margin: 15px 0;
        .ant-tag {
            margin-inline-end: 15px;
            padding-inline: 15px;
            border-radius: 0;
            font-size: 14px;
            line-height: 30px;
            cursor: pointer;
        }
    }
    .ant-table-cell {
        .ant-btn-link {
            padding: 4px;
        }
    }
`;

/* 对日期处理的方法 */
const zero = function zero(text) {
    text = String(text);
    return text.length < 2 ? '0' + text : text;
};
const formatTime = function formatTime(time) {
    let arr = time.match(/\d+/g),
        [, month, day, hours = '00', minutes = '00'] = arr;
    return `${zero(month)}-${zero(day)} ${zero(hours)}:${zero(minutes)}`;
};

const Task = function Task() {
    /* 表格列的数据 */
    const columns = [{
        title: '编号',
        dataIndex: 'id',
        align: 'center',
        width: '8%'
    }, {
        title: '任务描述',
        dataIndex: 'task',
        ellipsis: true,
        width: '50%'
    }, {
        title: '状态',
        dataIndex: 'state',
        align: 'center',
        width: '10%',
        render: text => +text === 1 ? '未完成' : '已完成'
    }, {
        title: '完成时间',
        dataIndex: 'time',
        align: 'center',
        width: '15%',
        render: (_, record) => {
            let { state, time, complete } = record;
            if (+state === 2) time = complete;
            return formatTime(time);
        }
    }, {
        title: '操作',
        render: (_, record) => {
            let { id, state } = record;
            return <>
                <Popconfirm title="您确定要删除此任务吗？"
                    onConfirm={() => { }}>
                    <Button type="link">删除</Button>
                </Popconfirm>
                {+state !== 2 ? <Popconfirm title="您确把此任务设置为完成吗？"
                    onConfirm={() => { }}>
                    <Button type="link">完成</Button>
                </Popconfirm> : null}
            </>;
        }
    }];

    return <StyledVoteBox>
        {/* 头部 */}
        <div className="header">
            <h2 className="title">TASK OA 任务管理系统</h2>
            <Button type="primary">新增任务</Button>
        </div>

        {/* 标签 */}
        <div className="tag-box">
            <Tag color='#1677ff'>全部</Tag>
            <Tag>未完成</Tag>
            <Tag>已完成</Tag>
        </div>

        {/* 表格 */}
        <Table columns={columns}
            dataSource={[]}
            loading={false}
            pagination={false}
            rowKey="id" />

        {/* 对话框 & 表单 */}
        <Modal title="新增任务窗口" open={true} confirmLoading={false} keyboard={false} maskClosable={false} okText="确认提交" onCancel={() => { }} onOk={() => { }}>
            <Form layout="vertical"
                initialValues={{ task: '', time: '' }}
                validateTrigger="onBlur">
                <Form.Item label="任务描述" name="task"
                    rules={[
                        { required: true, message: '任务描述是必填项' },
                        { min: 6, message: '输入的内容至少6位及以上' }
                    ]}>
                    <Input.TextArea rows={4}></Input.TextArea>
                </Form.Item>
                <Form.Item label="预期完成时间" name="time"
                    rules={[
                        { required: true, message: '预期完成时间是必填项' }
                    ]}>
                    <DatePicker showTime />
                </Form.Item>
            </Form>
        </Modal>
    </StyledVoteBox>
};
export default Task;