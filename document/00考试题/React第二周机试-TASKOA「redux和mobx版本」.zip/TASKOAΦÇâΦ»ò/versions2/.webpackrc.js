/* https://github.com/sorrycc/roadhog */
export default {
    hash: true,
    html: { template: './public/index.ejs' },
    disableCSSModules: true,
    disableCSSSourceMap: true,
    extraBabelPlugins: [
        [
            "import",
            { libraryName: "antd", libraryDirectory: "es", style: "css" }
        ]
    ],
    proxy: {
        "/api": {
            target: "http://127.0.0.1:9000",
            changeOrigin: true,
            pathRewrite: { "^/api": "" }
        }
    },
    env: {
        development: {
            extraBabelPlugins: ["dva-hmr"],
            browserslist: [
                "last 1 chrome version",
                "last 1 firefox version",
                "last 1 safari version"
            ]
        },
        production: {
            browserslist: [
                ">0.2%",
                "not dead",
                "not op_mini all"
            ]
        }
    }
};